export interface PostedJob {
    emailApplication: any;
    externalLink: any;
    employerId: any;
    companyName: String;
    jobTitle: String;
    jobLocation: String;
    jobIndustry: String;
    prefferedGender: String;
    requiredSkills: String;
    salaryRange: String;
    jobStatus: String;
    $id: String;
}
