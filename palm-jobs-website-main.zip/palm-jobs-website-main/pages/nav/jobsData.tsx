const jobData = [
    {
        id: 1,
        compName: 'Linear Company',
        jobTitle: 'Software Engineer',
        location: 'Addis Abeba',
        jobType: 'Part Time',
        salary: '40 - 50',
        postedTime: '29 min ago',
        description:
            'Mollit in laborum tempor Lorem incididunt irure. Aute eu ex ad sunt. Pariatur sint culpa do incididunt eiusmod eiusmod culpa. laborum tempor Lorem incididunt.'
    },
    {
        id:2,
        compName: 'YES',
        jobTitle: 'Driver',
        location: 'Jimma',
        jobType: 'Internshipt',
        salary: '2000',
        postedTime: '1w ago',
        description:
            'Mollit in laborum tempor Lorem incididunt irure. Aute eu ex ad sunt. Pariatur sint culpa do incididunt eiusmod eiusmod culpa. laborum tempor Lorem incididunt.'
    },
    {
        id: 3,
        compName: 'Nylos',
        jobTitle: 'Front-End Developer',
        location: 'Addis Abeba',
        jobType: 'Full Time',
        salary: '10,000',
        postedTime: '29 min ago',
        description:
            'Mollit in laborum tempor Lorem incididunt irure. Aute eu ex ad sunt. Pariatur sint culpa do incididunt eiusmod eiusmod culpa. laborum tempor Lorem incididunt.'
    },
    {
        id: 4,
        compName: 'Palm Jobs',
        jobTitle: 'Software Engineer',
        location: 'Addis Abeba',
        jobType: 'Part Time',
        salary: '40 - 50',
        postedTime: '29 min ago',
        description:
            'Mollit in laborum tempor Lorem incididunt irure. Aute eu ex ad sunt. Pariatur sint culpa do incididunt eiusmod eiusmod culpa. laborum tempor Lorem incididunt.'
    }
];
export default jobData;
